#!/bin/bash
#SBATCH --job-name=gnn                # Set job name to 'gnn'
#SBATCH --output=gnn_output_%j.log
#SBATCH --error=gnn_error_%j.log
#SBATCH --time=48:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=100GB
#SBATCH --gpus=1
#SBATCH --partition=work1
#SBATCH --constraint=gpu_v100

# Run the main script
python main.py
